import BSCollapse from 'bootstrap/js/src/collapse';

class Collapse extends BSCollapse {}

export { Collapse as default };
//# sourceMappingURL=collapse.js.map
