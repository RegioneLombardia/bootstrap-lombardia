import BSPopover from 'bootstrap/js/src/popover';

class Popover extends BSPopover {}

export { Popover as default };
//# sourceMappingURL=popover.js.map
